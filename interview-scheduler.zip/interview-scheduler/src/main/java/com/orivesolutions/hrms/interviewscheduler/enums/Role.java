package com.orivesolutions.hrms.interviewscheduler.enums;

public enum Role {
    ADMIN,
    HR,
    INTERVIEWER

}
