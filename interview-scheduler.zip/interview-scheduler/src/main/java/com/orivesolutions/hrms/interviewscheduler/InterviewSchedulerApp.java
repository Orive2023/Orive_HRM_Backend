package com.orivesolutions.hrms.interviewscheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterviewSchedulerApp {

    public static void main(String[] args) {
        SpringApplication.run(InterviewSchedulerApp.class, args);
    }
}
