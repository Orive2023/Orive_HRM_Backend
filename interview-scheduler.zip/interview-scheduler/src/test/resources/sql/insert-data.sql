INSERT INTO candidate (id,name, address, email_id, mobile, ctc, ectc, location, notice, resume_url, pin_code)
VALUES
    (1,'John Doe', '123 Main St', 'john.doe@example.com', '6300366542', 75000, 80000, 'New York', '2 weeks', 'http://example.com/john-resume.pdf', 10001);