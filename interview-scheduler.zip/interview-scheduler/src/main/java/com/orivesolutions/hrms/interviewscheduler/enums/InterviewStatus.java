package com.orivesolutions.hrms.interviewscheduler.enums;

public enum InterviewStatus {
    SCHEDULED,
    RE_SCHEDULED,
    CANCELLED,
    NO_SHOW,
    SELECTED,
    REJECTED,

}
