package com.orivesolutions.hrms.interviewscheduler.dto;

public class FeedbackDto {

}
